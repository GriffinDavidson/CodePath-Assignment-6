//
//  FeedViewController.swift
//  parstagram
//
//  Created by Griffin Davidson on 3/23/22.
//

import UIKit
import Parse
import AlamofireImage
import MessageInputBar

class FeedViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, MessageInputBarDelegate
{
    
    private let refreshControl = UIRefreshControl()
    private var posts = [PFObject]()
    private var numOfPosts = 20
    
    var selectedPost: PFObject!
    
    let commentBar = MessageInputBar()
    var showsCommentBar = false
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        
        tableView.keyboardDismissMode = .interactive
        
        self.title = "Parstagram • \(PFUser.current()!.username!)"
        
        refreshControl.addTarget(self, action: #selector(loadPosts), for: .valueChanged)
        tableView.refreshControl = refreshControl
        
        let center = NotificationCenter.default
        center.addObserver(self, selector: #selector(keyboardWillBeHidden(note:)), name: UIResponder.keyboardWillHideNotification, object: nil)
        
        commentBar.inputTextView.placeholder = "Add a comment..."
        commentBar.sendButton.title = "Post"
        commentBar.delegate = self
        
        // Do any additional setup after loading the view.
    }
    
    @objc func keyboardWillBeHidden(note: Notification)
    {
        commentBar.inputTextView.text = nil
        showsCommentBar = false
        becomeFirstResponder()
    }
    
    override var inputAccessoryView: UIView?
    {
        return commentBar
    }
    
    override var canBecomeFirstResponder: Bool
    {
        return showsCommentBar
    }
    
    override func viewDidAppear(_ animated: Bool)
    {
        super.viewDidAppear(animated)
        
        loadPosts()
    }
    
    func messageInputBar(_ inputBar: MessageInputBar, didPressSendButtonWith text: String)
    {
        // Create the comment
        let comment = PFObject(className: "comments")
        comment["text"] = text
        comment["post"] = selectedPost
        comment["author"] = PFUser.current()!
        
        selectedPost.add(comment, forKey: "comments")
        
        selectedPost.saveInBackground
        { (success, error) in
            if success
            {
                print("Comment saved!")
            }
            else
            {
                print("Error saving comment\nERROR: \(error?.localizedDescription ?? "failed to describe error")")
            }
        }
        
        tableView.reloadData()
        
        // clear and dissmiss
        commentBar.inputTextView.text = nil
        showsCommentBar = false
        becomeFirstResponder()
        commentBar.inputTextView.resignFirstResponder()
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath)
    {
        if indexPath.row + 3 == posts.count
        {
            loadMorePosts()
        }
    }
    
    @objc func loadPosts()
    {
        let query = PFQuery(className: "Posts")
        query.includeKeys(["owner", "comments", "comments.author"])
        query.limit = 20
        
        query.findObjectsInBackground
        { (posts, error) in
            if posts != nil
            {
                self.posts = posts!
                self.tableView.reloadData()
                self.numOfPosts = 20
            }
            else
            {
                print("Failed to fetch posts!")
            }
        }
        
        refreshControl.endRefreshing()
    }
    
    func loadMorePosts()
    {
        let query = PFQuery(className: "Posts")
        query.includeKey("owner")
        query.limit = 20
        query.skip = numOfPosts
        numOfPosts += 20
        
        query.findObjectsInBackground
        { (posts, error) in
            if posts != nil
            {
                self.posts += posts!
                self.tableView.reloadData()
            }
            else
            {
                print("Failed to fetch posts!")
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        let post = posts[section]
        let comments = (post["comments"] as? [PFObject]) ?? []
        
        return comments.count + 2
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let post = posts[indexPath.section]
        let comments = (post["comments"] as? [PFObject] ?? [])
        
        if indexPath.row == 0
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "PostTableViewCell") as! PostTableViewCell
            
            let user = post["owner"] as! PFUser
            cell.postOwnerLabel.text = user.username
            
            cell.postCaptionLabel.text = (post["caption"] as! String)
            
            let imageFile = post["image"] as! PFFileObject
            let urlString = imageFile.url!
            let url = URL(string: urlString)!
            
            cell.postPhotoImageView.af.setImage(withURL: url)
            
            return cell
        }
        else if indexPath.row <= comments.count
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "CommentTableViewCell") as! CommentTableViewCell
            
            let comment = comments[indexPath.row - 1]
            
            cell.commentLabel.text = (comment["text"] as! String)
            
            let user = comment["author"] as! PFUser
            cell.userLabel.text = user.username
            
            return cell
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "addCommentCell")!
            
            return cell
        }
    }
    
    @IBAction func onLogout(_ sender: Any)
    {
        UserDefaults.standard.set(false, forKey: "isLoggedIn")
        PFUser.logOut();
        self.dismiss(animated: true)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let post = posts[indexPath.section]
        let comments = (post["comments"] as? [PFObject] ?? [])
        
        if indexPath.row == comments.count + 1
        {
            showsCommentBar = true
            becomeFirstResponder()
            commentBar.inputTextView.becomeFirstResponder()
            
            selectedPost = post
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
